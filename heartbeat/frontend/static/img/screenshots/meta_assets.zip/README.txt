Instructions:
1. Upload all .png images in this zip file to '/static/img/meta/' on your website.
2. Upload the 'manifest.json' file to the root of your website.
3. Copy the code from _header_tags.html and paste it into the <head> section of your main HTML file.