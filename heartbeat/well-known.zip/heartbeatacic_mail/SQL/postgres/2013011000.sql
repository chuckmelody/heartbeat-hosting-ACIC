CREATE TABLE "system" (
    name varchar(64) NOT NULL PRIMARY KEY,
    value text
);
